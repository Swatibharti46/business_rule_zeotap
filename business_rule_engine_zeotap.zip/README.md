# business_rule_engine_zeotap

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/Swatibharti46/business_rule_engine_zeotap)